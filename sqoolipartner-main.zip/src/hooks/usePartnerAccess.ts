import { useAuth } from './useAuth';

export interface PartnerAccessConfig {
  partnerType: string | null;
  accessLevel: number | null;
  commissionRate: number | null;
  canAccessDashboard: boolean;
  canAccessCampaigns: boolean;
  canAccessWallet: boolean;
  canAccessReports: boolean;
  canAccessUsers: boolean;
  canAccessPrograms: boolean;
  canAccessSettings: boolean;
  canAccessSection: (section: string) => boolean;
  getAvailableSections: () => string[];
}

const SECTION_ACCESS_BY_PARTNER_TYPE: Record<string, string[]> = {
  affiliate: ['dashboard', 'campaigns', 'wallet'],
  media: ['dashboard', 'campaigns', 'wallet', 'reports'],
  corporate: ['dashboard', 'campaigns', 'wallet', 'reports'],
  institutional: ['dashboard', 'campaigns', 'wallet', 'reports', 'users', 'programs', 'settings'],
};

const SECTION_ACCESS_BY_LEVEL: Record<number, string[]> = {
  0: [],
  25: ['dashboard', 'campaigns', 'wallet'],
  35: ['dashboard', 'campaigns', 'wallet', 'reports'],
  40: ['dashboard', 'campaigns', 'wallet', 'reports'],
  45: ['dashboard', 'campaigns', 'wallet', 'reports', 'users', 'programs', 'settings'],
  100: ['dashboard', 'campaigns', 'wallet', 'reports', 'users', 'programs', 'settings'],
};

export function usePartnerAccess(): PartnerAccessConfig {
  const { partner, user } = useAuth();

  // Extract partner type and access level from partner data
  const partnerType: string | null = (partner as any)?.partner_type || null;
  const accessLevel: number | null = (partner as any)?.access_level || null;
  const commissionRate: number | null = (partner as any)?.commission_rate || null;
  const userRole: string | null = (user as any)?.role || null;

  /**
   * Determine available sections based on partner type
   * Falls back to access level if partner type not available
   * NOTE: admin_partner role gets full access regardless of partner_type
   */
  const getAvailableSections = (): string[] => {
    // Priority 1: Admin partner role always gets full access
    if (userRole === 'admin_partner' || userRole === 'super_admin') {
      return ['dashboard', 'campaigns', 'wallet', 'reports', 'users', 'programs', 'settings'];
    }

    // Priority 2: Check access level (highest access)
    if (accessLevel !== null && SECTION_ACCESS_BY_LEVEL[accessLevel]) {
      return SECTION_ACCESS_BY_LEVEL[accessLevel];
    }

    // Priority 3: Check partner type
    if (partnerType && SECTION_ACCESS_BY_PARTNER_TYPE[partnerType]) {
      return SECTION_ACCESS_BY_PARTNER_TYPE[partnerType];
    }

    // Default: Affiliate access (lowest)
    return SECTION_ACCESS_BY_PARTNER_TYPE.affiliate;
  };

  // Debug: print resolved partner access info in dev
  try {
    // Avoid cluttering production logs. Use Vite's `import.meta.env.MODE`
    // instead of `process.env` so we don't require Node type defs in the
    // frontend bundle/tsconfig.
    const isDev = typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env.MODE !== 'production';
    if (isDev) {
      const dbg = {
        partner: partner || null,
        partnerType,
        accessLevel,
        availableSections: getAvailableSections(),
      };
      // eslint-disable-next-line no-console
      console.debug('usePartnerAccess.debug:', dbg);
    }
  } catch (e) {
    // ignore
  }

  /**
   * Check if user can access a specific section
   */
  const canAccessSection = (section: string): boolean => {
    const available = getAvailableSections();
    return available.includes(section.toLowerCase());
  };

  const availableSections = getAvailableSections();

  return {
    partnerType,
    accessLevel,
    commissionRate,
    canAccessDashboard: canAccessSection('dashboard'),
    canAccessCampaigns: canAccessSection('campaigns'),
    canAccessWallet: canAccessSection('wallet'),
    canAccessReports: canAccessSection('reports'),
    canAccessUsers: canAccessSection('users'),
    canAccessPrograms: canAccessSection('programs'),
    canAccessSettings: canAccessSection('settings'),
    canAccessSection,
    getAvailableSections,
  };
}
